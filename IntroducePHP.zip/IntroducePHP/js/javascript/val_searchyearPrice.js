// JavaScript Document
/* Author: Dan DU
	Date: 10/10/2016
   validate search condition, minprice, maxprice, minyear, maxyear in houselistMap.php page
**/
    	function validateMinPrice(){
			var  minPrice = document.getElementById("minPrice");
			if(  minPrice == null || isNaN(minPrice.value)){
					alert("minimum price must be number ");
					minPrice.focus();
					$('#minPrice').css("background-color","red");
					return false;
			}
			$('#minPrice').css("background-color","white");
			return true;
		}
		
		function validateMaxPrice(){
			var  maxPrice = document.getElementById("maxPrice");
			if( maxPrice == null  || isNaN(maxPrice.value)){
					alert("maxmum price must be number ");
					maxPrice.focus();
					$('#maxPrice').css("background-color","red");
					return false;
			}
			$('#maxPrice').css("background-color","white");
			return true;
		}
		
    	function validateMinYear(){
			var  minPrice = document.getElementById("minYear");
			if( minYear == null || isNaN(minYear.value)){
					alert("minimum year must be number ");
					minPrice.focus();
					$('#minYear').css("background-color","red");
					return false;
			}
			$('#minYear').css("background-color","white");
			return true;
		}
		
    	function validateMaxYear(){
			var  maxYear = document.getElementById("maxYear");
			if(maxYear == null  || isNaN(maxYear.value)){
					alert("maxmum year must be number ");
					maxYear.focus();					
					$('#maxYear').css("background-color","red");
					return false;
			}
			$('#maxYear').css("background-color","white");
			return true;
		}
		
		function validateMinCashFlow(){
			var  minCashFlow = document.getElementById("minCashFlow");
			if( minCashFlow == null || isNaN(minCashFlow.value)){
					alert("minimum Cash Flow must be number ");
					minCashFlow.focus();
					$('#minCashFlow').css("background-color","red");
					return false;
			}
			$('#minCashFlow').css("background-color","white");
			return true;
		}
		
    	function validateMaxCashFlow(){
			var  maxCashFlow = document.getElementById("maxCashFlow");
			if(maxCashFlow == null  || isNaN(maxCashFlow.value)){
					alert("maxmum CashFlow must be number ");
					maxCashFlow.focus();
					$('#maxCashFlow').css("background-color","red");
					return false;
			}
			$('#maxCashFlow').css("background-color","white");
			return true;
		}
		function val_location(){
			var locationValue = document.getElementById('location').value;
			if(locationValue == "" || locationValue.length == 0){
				alert("This field is required! please enter eg: zip(20170) , state code(VA)  or city name(Fairfax)")
				return false;
			}
			else if( !isNaN(locationValue) &&(locationValue.length != 5)){
			 		alert("ZipCode length should be 5 instead of "+locationValue.length );
					return false;
			}
			return true;
		}
		function val_search(){
			if(val_location()&&validateMinPrice()&&validateMaxPrice()&&validateMinYear()&&validateMaxYear()&&validateMinCashFlow()&&validateMaxCashFlow())
			{
			document.getElementById('searchForSale').submit();
			}
			return false;
	   }
