// JavaScript Document
//slider bar for price range
$(function(){
		$("#slider_price").slider({
		   range:true,
			min: 0,
			max: 2000000,
			values:[ 1000 ,2000000 ],
			step: 100,
			animate: "fast",
			classes: {"ui-slider": "highlight"},
			slide: function(event, ui){
				$( "#amount" ).html( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
				$("#minPrice").val(ui.values[0]);
				$("#maxPrice").val(ui.values[1]);
			}
		});	
		//initial price
		 $( "#amount" ).html( "$" + $( "#slider_price" ).slider( "values", 0 ) +" - $" + $( "#slider_price" ).slider( "values", 1 ) );
		 $( "#minPrice" ).val($( "#slider_price" ).slider( "values", 0 ));
		 $( "#maxPrice" ).val($( "#slider_price" ).slider( "values", 1 ));
	} );
	
//slider bar for year range
$(function(){
		$("#slider_year").slider({
		   range:true,
			min: 0,
			max: 2016,
			values:[ 0 ,2016 ],
			step: 1,
			slide: function(event, ui){
				$( "#yearRg" ).html( " From : " + ui.values[ 0 ] + " - To: " + ui.values[ 1 ] );
				$("#minYear").val(ui.values[0]);
				$("#maxYear").val(ui.values[1]);
			}
		});	
		//initial year
		 $( "#yearRg" ).html( " From: "+ $( "#slider_year" ).slider( "values", 0 ) +" - To: " + $( "#slider_year" ).slider( "values", 1 ) );
		 $( "#minYear" ).val($( "#slider_year" ).slider( "values", 0 ));
		 $( "#maxYear" ).val($( "#slider_year" ).slider( "values", 1 ));
	} );
	
//slider bar for SQFT range
$(function(){
		$("#slider_SQFT").slider({
		   range:true,
			min: 0,
			max: 10000,
			values:[ 0 ,10000 ],
			step: 10,
			slide: function(event, ui){
				$( "#SQFTRg" ).html( " From : " + ui.values[ 0 ] + "sqft - To: " + ui.values[ 1 ] +"sqft");
				$("#slider_SQFT_min").val(ui.values[0]);
				$("#slider_SQFT_max").val(ui.values[1]);
			}
		});	
		//initial price
		 $( "#SQFTRg" ).html( " From: "+ $( "#slider_SQFT" ).slider( "values", 0 ) +"sqft - To: " + $( "#slider_SQFT" ).slider( "values", 1 )+"sqft" );
		 $( "#slider_SQFT_min" ).val($( "#slider_SQFT" ).slider( "values", 0 ));
		 $( "#slider_SQFT_max" ).val($( "#slider_SQFT" ).slider( "values", 1 ));
	} );
	