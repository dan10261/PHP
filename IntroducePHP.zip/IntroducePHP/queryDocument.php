<?php 
	require 'vendor/autoload.php';
	$client = new MongoDB\Client;
	$mydb = $client->mydb;
	$myZillow = $mydb->myZillow;
	$listHouses = $myZillow->find(
	['State'=>'VA']
	);
	echo '<table border="1">';
	echo '<tr>
			 <th>Address</td>
			 <th>Locality</td>
			 <th>State</td>
			 <th>ZipCode</td>
			 <th>Latitude</td>
			 <th>Longitude</td>
			 <th>EstimatedPriceRent</td>
			 <th>Bedrooms</td>
			 <th>Bathrooms</td>
			 <th>AreaSpace</td>
			 <th>Status</td>
			 <th>EstimatedRent</td>
			 <th>YearBuilt</td>
			 <th>HOAFee</td>
			 <th>DaysonZillow</td>
			 <th>ViewsSinceListing</td>
			 <th>Index2</td>
			 <th>Mortgage</td>
			 <th>RentSale</td>
			 <th>AvgIndex2</td>
			 <th>CashFlow</td>
			 <th>AvgPrice</td>
			 <th>AvgCashFlow</td>
			 <th>AvgRent</td>
			 <th>PriceperSQFT</td>
			 <th>AvgPriceSQFT</td>
			 <th>StandardDeviation</td>
		  </tr>';
	foreach($listHouses as $house){
	    echo '<tr>
			 <td>' .$house['Address']. '</td>'
			 .'<td>'.$house['Locality'].'</td>'
			 .'<td>'.$house['State'].'</td>'
			 .'<td>'.$house['ZipCode'].'</td>'
			 .'<td>'.$house['Latitude'].'</td>'
			 .'<td>'.$house['Longitude'].'</td>'
			 .'<td>'.$house['EstimatedPriceRent'].'</td>'
			 .'<td>'.$house['Bedrooms'].'</td>'
			 .'<td>'.$house['Bathrooms'].'</td>'
			 .'<td>'.$house['AreaSpace'].'</td>'
			 .'<td>'.$house['Status'].'</td>'
			 .'<td>'.$house['EstimatedRent'].'</td>'
			 .'<td>'.$house['YearBuilt'].'</td>'
			 .'<td>'.$house['HOAFee'].'</td>'
			 .'<td>'.$house['DaysonZillow'].'</td>'
			 .'<td>'.$house['ViewsSinceListing'].'</td>'
			 .'<td>'.$house['Index2'].'</td>'
			 .'<td>'.$house['Mortgage'].'</td>'
			 .'<td>'.$house['RentSale'].'</td>'
			 .'<td>'.$house['AvgIndex2'].'</td>'
			 .'<td>'.$house['CashFlow'].'</td>'
			 .'<td>'.$house['AvgPrice'].'</td>'
			 .'<td>'.$house['AvgCashFlow'].'</td>'
			 .'<td>'.$house['AvgRent'].'</td>'
			 .'<td>'.$house['PriceperSQFT'].'</td>'
			 .'<td>'.$house['AvgPriceSQFT'].'</td>'
			 .'<td>'.$house['StandardDeviation'].'</td>'
			  .'</tr>';
	}
	echo '</table>'
?>