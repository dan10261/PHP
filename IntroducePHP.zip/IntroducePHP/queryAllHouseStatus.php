<?php
	require 'vendor/autoload.php';
	$client = new MongoDB\Client;
	$mydb = $client->mydb;
	$myZillow = $mydb->myZillow;
	$listStatus = $myZillow->distinct("Status");
	$return='';
	foreach($listStatus as $status){
		if(strcasecmp(trim($status),"Status") == 0   || strlen(trim($status)) == 0) continue;
	   $return .= '<option value='.str_replace(" ", "//", $status).'>'.
					$status
				 .'</option>';
	}
	echo $return;
?>