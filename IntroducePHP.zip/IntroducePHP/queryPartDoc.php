<?php 
	require 'vendor/autoload.php';
	$client = new MongoDB\Client;
	$mydb = $client->mydb;
	$myZillow = $mydb->myZillow;
	if(!isset($_GET["skip"])){
		$skip = 0;
	}else{
		$skip=$_GET["skip"];
	}
	$skip = $skip*10;
	$countAll=0;
	/*case  sensitive eg: Fairfax and fairfax is differet.*/
	//$location =  strtoupper($_POST["location"]); 
	$listHouses = $myZillow->find();
	foreach($listHouses as $house){
		$countAll++;
	}
	if(strlen($location) == 2){
	$listHouses = $myZillow->find(
		['State'=>$location],
		[
			'limit'=> 10,
			'skip'=> $skip
		]
		);
	}else if(is_numeric($location)){
		$listHouses = $myZillow->find(
		['ZipCode'=>intval($location)],
		[
			'limit'=> 10,
			'skip'=> $skip
		]
	    );
	}else{
		$listHouses = $myZillow->find(
		 ['Locality'=>$location],
		 [
			'limit'=> 10,
			'skip'=> $skip
		 ]
	 	);
	}
?>