
 <?php 
			$arrVal = array(0,1,2,3,4,5,6);
			foreach($arrVal as $av){
				echo '
				<option value='.$av.' >
				<strong>'.$av.'+ Baths</strong>
				</option>';
			}
?>