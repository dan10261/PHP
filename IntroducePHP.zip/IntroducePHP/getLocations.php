<?php 
 	require 'vendor/autoload.php';
	$client = new MongoDB\Client;
	$mydb = $client->mydb;
	$myZillow = $mydb->myZillow;
	
	$location = $_POST["location"];
	$Bedrooms = $_POST["Bedrooms"];
	$Bathrooms = $_POST["Bathrooms"];
	$minYear = $_POST["minYear"];
	$maxYear = $_POST["maxYear"];
	$minPrice = $_POST["minPrice"];
	$maxPrice = $_POST["maxPrice"];
	$minCashFlow = $_POST["minCashFlow"];
	$maxCashFlow = $_POST["maxCashFlow"];
	$Status = $_POST["Status"];
	//$location = "fairfAx";
	//$Bedrooms =3;
	//$Bathrooms = 4;
	//$minYear=1960;
	//$maxYear = 2016;
	//$minPrice = 494999;
	//$maxPrice = 495001;
	
	$queryArray = array();
	if(strlen(''.$location) == 2){
		$queryArray = array_merge($queryArray,array('State' => strtoupper($location)));	
	}else if(is_numeric($location)){
		$queryArray = array_merge($queryArray,array('ZipCode' => intval($location)));	
	}else if(strlen(''.$location) != 0){
		$queryArray = array_merge($queryArray,array( 'Locality'=>strtoupper($location)));
	}
	if(strlen(''.$Bedrooms) !=0){
		$queryArray = array_merge($queryArray,array('Bedrooms' => array('$gte' =>intval($Bedrooms))));
	}
	if(strlen(''.$Bathrooms) !=0){
		$queryArray = array_merge($queryArray,array('Bathrooms' => array('$gte' => intval($Bathrooms))));
	}
	if(strlen(''.$Status) !=0){
		$queryArray = array_merge($queryArray,array('Status' => str_replace("//", " ", $Status)));
	}
	if(strlen(''.$minYear) !=0 && strlen(''.$minYear) !=0){
		$queryArray = array_merge($queryArray,array('YearBuilt'=>array( '$gte' => intval($minYear), '$lte' => intval($maxYear))));
	}else if (strlen(''.$minYear) !=0){
		$queryArray = array_merge($queryArray,array('YearBuilt' =>array( '$gte' => intval($minYear))));
	}else if (strlen(''.$maxYear) != 0){
		$queryArray = array_merge($queryArray,array('YearBuilt' =>array( '$lte' => intval($maxYear) )));
	}
	
	if(strlen(''.$minPrice) !=0 && strlen(''.$maxPrice) !=0){
		$queryArray = array_merge($queryArray,array('EstimatedPriceRent' =>array( '$gte' => intval($minPrice), '$lte' => intval($maxPrice) )));
	}else if (strlen(''.$minPrice) !=0){
		$queryArray = array_merge($queryArray,array('EstimatedPriceRent' =>array( '$gte' => intval($minPrice))));
	}else if (strlen(''.$maxPrice) !=0){
		$queryArray = array_merge($queryArray,array('EstimatedPriceRent' =>array( '$lte' => intval($maxPrice) )));
	}
	
	if(strlen(''.$minCashFlow) !=0 && strlen(''.$maxCashFlow) !=0){
		$queryArray = array_merge($queryArray,array('CashFlow' =>array( '$gte' => intval($minCashFlow), '$lte' => intval($maxCashFlow) )));
	}else if (strlen(''.$minCashFlow) !=0){
		$queryArray = array_merge($queryArray,array('CashFlow' =>array( '$gte' => intval($minCashFlow))));
	}else if (strlen(''.$maxCashFlow) !=0){
		$queryArray = array_merge($queryArray,array('CashFlow' =>array( '$lte' => intval($maxCashFlow) )));
	}
	
	/*
	$queryArray = array(
    'State' => $location,
    'Bedrooms' => array('$gte' =>$Bedrooms),
	'Bathrooms' => array('$gte' => $Bathrooms),
	'EstimatedPriceRent' =>array( '$gte' => $minPrice, '$lte' => $maxPrice ),
	'YearBuilt'=>array( '$gte' => $minYear, '$lte' => $maxYear )
  	);
	var_dump($queryArray);
	echo('<br/>');
	*/
	$listHouses = $myZillow->find($queryArray);
     /*
  	foreach($listHouses as $house)
  	{
		  var_dump($house);
  	}
  	*/
	//$Bathrooms=$_POST["Bathrooms"];
    /*
		if(strlen($location) == 2){
			$listHouses = $myZillow->find(
				['State'=>$location]
			);
		}else if(is_numeric($location)){
			$listHouses = $myZillow->find(
				[
				'ZipCode'=>intval($location)
			//	',Bedrooms'=>$Bedrooms,
				//'Bathrooms'=>$Bathrooms
			 	]
			);
		}else{
			$listHouses = $myZillow->find(
		 		[
				'Locality'=>$location
				//,
				//'Bedrooms'=>$Bedrooms,
				//'Bathrooms'=>$Bathrooms
			 	]
		);
		}
	 //$location1 = array('lat'=> 38.858003, 'lng'=> -77.270596);
	 //$location2 = array('lat'=> 38.870298 ,'lng'=> -77.258868);
	 //$location3 = array('lat'=> 38.874225, 'lng'=> -77.274322);
	 */
	 $listLocations ='[';
	 $i=0;
	 foreach($listHouses as $house){
		 $location = array('ZPID'=>$house['ZPID'],'lat'=> $house['Latitude'],'lng'=>$house['Longitude']);
	     $i++;
		 if($i == 1){
			$listLocations .= json_encode($location);
		 	continue;
		 }
		 $listLocations .=',';
		 $listLocations .= json_encode($location);
	}
	 // echo json_encode($location1);
	//echo  '['.json_encode($location1) . ',' .json_encode($location2) .',' . json_encode($location2).']';
	
	echo $listLocations.']';
	
?>