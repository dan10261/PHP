<?php

    require_once "vendor/autoload.php";
	//connect to mongodb
	$client = new MongoDB\Client;
	$zillowdb = $client->mydb;
	$myZillowConll = $zillowdb->myZillow;
	$insertManyResult="";
	//read data from excel file
	$fileName = "project_data.csv";
	$excelReader = PHPExcel_IOFactory::createReaderForFile($fileName);
	$excelObj = $excelReader->load($fileName);
	$excelReader->setReadDataOnly(true);
	//get all sheet anmes from the file
	$worksheetNames = $excelObj->getSheetNames($fileName);
	//$return = array();
	foreach($worksheetNames as $key =>$sheetName){
	$excelObj->setActiveSheetIndexByName($sheetName);
	//create an assoc array with the sheet name as key and the sheet contents array as value
	//$return[$sheetName] = $excelObj->getActiveSheet()->toArray(null, true,true,true);
	$sheetData = $excelObj->getActiveSheet();
	$highestRow = $sheetData->getHighestRow(); 
	$highestColumn = $sheetData->getHighestColumn(); 
	$highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn); 
    
	//insert data from excel to mongodb
	
	for ($row = 1; $row <= $highestRow; ++$row) {
	$col = 0;
    $ZPID = $sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$Address = $sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$Locality=strtoupper($sheetData->getCellByColumnAndRow($col, $row)->getValue());
	$col++;
	$State=strtoupper($sheetData->getCellByColumnAndRow($col, $row)->getValue());
	$col++;
	$ZipCode=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$Latitude=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$Longitude=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$EstimatedPriceRent=intval(substr($sheetData->getCellByColumnAndRow($col, $row)->getValue(),1));
	$col++;
	$Bedrooms=intval(substr($sheetData->getCellByColumnAndRow($col, $row)->getValue(),0,1));
	$col++;
	$Bathrooms=intval(substr($sheetData->getCellByColumnAndRow($col, $row)->getValue(),0,1));
	$col++;
	$AreaSpace=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$Status=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$EstimatedRent=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$YearBuilt=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$HOAFee=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$DaysonZillow=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$ViewsSinceListing=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$Index2=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$Mortgage=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$RentSale=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$AvgIndex2=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$CashFlow=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$AvgPrice=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$AvgCashFlow=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$AvgRent=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$PriceperSQFT=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$AvgPriceSQFT=$sheetData->getCellByColumnAndRow($col, $row)->getValue();
	$col++;
	$StandardDeviation=$sheetData->getCellByColumnAndRow($col, $row)->getValue();		
	$insertManyResult = $myZillowConll->insertMany([
	    [
		'ZPID'=>$ZPID,
		 'Address'=>$Address,
		 'Locality'=>$Locality, 
		 'State'=>$State,
		 'ZipCode'=>$ZipCode,
		 'Latitude'=>$Latitude,
		 'Longitude'=>$Longitude,
		 'EstimatedPriceRent'=>$EstimatedPriceRent,
		 'Bedrooms'=>$Bedrooms,
		 'Bathrooms'=>$Bathrooms,
		 'AreaSpace'=>$AreaSpace,
		 'Status'=>$Status,
		  'EstimatedRent'=>$EstimatedRent,
		  'YearBuilt'=>$YearBuilt,
		  'HOAFee'=>$HOAFee,
		  'DaysonZillow'=>$DaysonZillow,
		  'ViewsSinceListing'=>$ViewsSinceListing,
		  'Index2'=>$Index2,
		  'Mortgage'=>$Mortgage,
		  'RentSale'=>$RentSale,
		  'AvgIndex2'=>$AvgIndex2,
		  'CashFlow'=>$CashFlow,
		  'AvgPrice'=>$AvgPrice,
		  'AvgCashFlow'=>$AvgCashFlow,
		  'AvgRent'=>$AvgRent,
		  'PriceperSQFT'=>$PriceperSQFT,
		  'AvgPriceSQFT'=>$AvgPriceSQFT,
		  'StandardDeviation'=>$StandardDeviation
		 ]
	]);
   }
}
   printf("Insert %d document",$insertManyResult->getInsertedCount());
	
	/**** display data from excel
	echo '<table>';
	for ($row = 1; $row <= $highestRow; ++$row) {
    echo '<tr>';

    for ($col = 0; $col <= $highestColumnIndex; ++$col) {
    echo '<td>' . $sheetData->getCellByColumnAndRow($col, $row)->getValue() . '</td>';
    }

    echo '</tr>';
	}
	echo '</table>';
	
	}
	***/
?>