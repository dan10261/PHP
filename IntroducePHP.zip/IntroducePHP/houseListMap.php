<!DOCTYPE html>
<html>
  <head>
    <title>Simple Map</title>
    <meta name="viewport" content="initial-scale=1.0">
    <meta charset="utf-8">
    <link href="css/header.css" rel="stylesheet" type="text/css"/>
	<link href="css/searchHouses.css" rel="stylesheet" type="text/css"/>
	<link href="css/listHousesPage2.css" rel="stylesheet" type="text/css"/>
    <link href="css/listHousesPage1.css" rel = "stylesheet" type="text/css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="js/javascript/val_searchyearPrice.js"></script>
    <script src="js/jquery/showHideYearPricePnl.js"></script>
    <script>
	$(document).ready(function(){
    	$("#searchBeds").on("click", function() {
    		$(this).css("color", "#000");
		});
		$("#searchBaths").on("click", function() {
    		$(this).css("color", "#000");
		});
		$("#searchBeds").on("mouseout", function() {
    		$(this).css("color", "#000");
		});
		$("#searchBaths").on("mouseout", function() {
    		$(this).css("color", "#000");
		});
		$("#searchBaths").on("mouseout", function() {
    		$(this).css("color", "#000");
		});
		$("#searchBeds").on("mouseover", function() {
    		$(this).css("color", "#0ff");
		});
		$("#searchBaths").on("mouseover", function() {
    		$(this).css("color", "#0ff");
		});
	});
    </script>
    <style>
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #map {
		float:left;
        height: 100%;
		width:70%;
      }
	  #houseDetails{
	  	float: right;
		width:30%;
	  }
	  .search_nav{margin:0px;padding:0px;}
	 .search_nav li{display:inline;}
	 .search_nav li a {
    	color: #000;
    	padding: 5px 26px;
		margin-bottom:2px;
    	text-decoration: none;}
	 .search_nav li a:hover {
   	 	background-color: #3FF;
    	color: #fff;}
		#showPricePnl:hover, #showYearPnl:hover, #showMorePnl:hover{
		color:#0ff;
		}
  </style>
  </head>
  
  <body onLoad="initMap()">
	<!--search div--->
    <form id="searchForSale" name="searchForSale" action="houseListMap.php" method="post" >
    <div id="search_div" style="background-color:#65D3E0;;padding:2px 10px; clear:both; float:inherit;">
        <ul class = "search_nav"  >
  			<li ><a href="searchHouses.php" ><strong>Home</strong></a></li>
  			<li style="padding:10px; border-left:1px solid #FFF">
             	<div  id="searchBedsDiv" style="display:inline;background-color:#65D3E0; ">
                <select id="searchBeds" name="Bedrooms" style="background-color:transparent; border:0">
						<?php include("utils/bld_bedNum.php")?>
				</select>
                </div>
			</li>
            <li style=" padding:10px; border-left:1px solid #FFF">
            <div id="searchBathsDiv" style="display:inline; background-color:#65D3E0; ">
                <select id="searchBaths" name="Bathrooms" style="background-color:transparent; border:0">
						<?php include("utils/bld_bathNum.php")?>
				</select>
            </div>
            </li>
            <li style="border-left:1px solid #FFF; padding:10px;">
            <div style="display:inline; padding:0px;">
            <fieldset style="width:auto;padding:0;margin:-10px; border:0;display:inline;">
            <legend title="Beds">
                			<p id = "showPricePnl" ><strong>Price Range</strong><p>
              </legend>
                	<div id="showPrice" style="display:none;
                        						z-index:2; 
                                                position:absolute;
                                                background-color:#FFF;">
                              			<div style="padding:0px; display:inline;" class="search-bb">
                            			<p>Min Price:</p>
                                        <input type="text" id="minPrice" name="minPrice"  onChange="return validateMinPrice();" style="border-radius: 10px;"/> 
                                        </div>
                                        <div style="padding:0px; display:inline;" class="search-bb">
                                        <p>Max Price:</p>       
                              			<input type="text" id="maxPrice" name="maxPrice" onChange="return validateMaxPrice();" style="border-radius: 10px;"/>    
                                        </div>    
                     </div>
            </fieldset>
            </div>	
            </li>
            <li style="border-left:1px solid #FFF; padding:10px;">
            <div style="display:inline; padding:0px;">
            <fieldset style="width:auto;padding:0px;margin:-10px; border:0;display:inline;">
            <legend title="Beds">
                			<p id = "showYearPnl" ><strong>Year Built</strong><p>
              </legend>
                		<div id="showYear" style="display:none;
                        						z-index:2; 
                                                position:absolute;
                                                background-color:white;
                                                padding-top:2px;">
                         				<div style="display:inline;" class="search-bb">
                                        	<p>Min Year:</p>
                                        <input type="text"  id="minYear" name="minYear" maxlength="4" onChange="return validateMinYear();" style="border-radius: 10px;"/>
					  					</div>
                                        <div style="display:inline;" class="search-bb">
                                        	<p>Max Year:</p>		    
                     					<input type="text" id="maxYear" name="maxYear" maxlength="4" onChange="return validateMaxYear();" style="border-radius: 10px;"/>
                                        </div>
                        </div>
                         
			</fieldset>
            	 </div>      
            </li>
            <li style="border-left:1px solid #FFF; padding:10px;">
            <div style="display:inline; padding:0px;">
            <fieldset style="width:auto;padding:0px;margin:-10px; border:0;display:inline;">
            <legend title="More">
                			<p id = "showMorePnl" style="padding:0px; height:100%;margin:0;" > 
                            	<strong>More<img width="20px" height="100%" src="images/moreOptions_dot.png">
                            	</strong>
                            <p>
              </legend>
                		<div id="showMore" style="display:none;
                        						z-index:2; 
                                                position:absolute;
                                                background-color:white;
                                                padding-top:2px;">
                                    <div id="showCashFlow" style="display:block;" 
                                                class="search-bb">
                                    	<label>Cash Flow<br/>
                         				<div style="display:inline;">
                                        	Min:
                                        	<input type="text"  
                                                   id="minCashFlow" 
                                                   name="minCashFlow" 
                                                   maxlength="20" 
                                                   onChange="return validateMinCashFlow();" style="border-radius: 10px;"/>
					  					</div>
                                        <div style="display:inline;">
                                        	Max:		    
                     						<input type="text" 
                                                   id="maxCashFlow" 
                                                   name="maxCashFlow" 
                                                   maxlength="20" 
                                                   onChange="return validateMaxCashFlow();" style="border-radius: 10px;"/>
                                        </div>
                                        </label>
                                    </div>
                                    <div id="showStatus" style="display:block;">
                                    	<label  class="search-bb">
											Property Status
											<br>
											<select id="type" name="Status">
												<option value="">
													All Available
												</option>
												<?php include("queryAllHouseStatus.php")?>
                     						</select>
										</label>
                                    </div>
                        </div>
                         
			</fieldset>
            	 </div>      
            </li>
            <li style="border-left:1px solid #FFF; padding:10px;">
                <div  style="display:inline;">
                    <div style="display:inline;">
					<input type="text" 
                    	   id="location" 
                           name="location" 
                           style="padding:5px;border-radius:8px; width: 350px;" 
                           placeholder="City(Fairfax), State Code(VA) Or ZIP(20170)">
					</div>
               </div>
            </li>   
            <li style="border-left:1px solid #FFF; padding:10px;"> 
                <div  style="display:inline;">
            		<div style="display:inline;">
						<input type="button" value="Search" onClick="return val_search();" style="border-radius:5px; background: #f7841b; margin:0px; padding:6px; color:white" >
					</div>
				</div>
            </li>
  		</ul>
     </div><!----end search Nav--->
     </form>
    <!---Map div-->
    <div id="map" style=""></div>
    <div id = "houseDetails"></div>
    <script>
function initMap() {
var lct = '<?php echo $_POST['location'];?>';
var minYear = '<?php echo $_POST['minYear'];?>';
var maxYear = '<?php echo $_POST['maxYear'];?>';
var minPrice = '<?php echo $_POST['minPrice'];?>';
var maxPrice = '<?php echo $_POST['maxPrice'];?>';
var minCashFlow = '<?php echo $_POST['minCashFlow'];?>';
var maxCashFlow = '<?php echo $_POST['maxCashFlow'];?>';
var Bedrooms = '<?php echo $_POST['Bedrooms'];?>';
var Bathrooms = '<?php echo $_POST['Bathrooms'];?>';
var Status = '<?php echo $_POST['Status'];?>';
console.log('minyear:'+minYear);
console.log('maxyear: ' +maxYear);
console.log('minPirce: ' +minPrice);
console.log('maxPrice:'+maxPrice);
console.log('minCashFlow: ' +minCashFlow);
console.log('maxCashFlow:'+maxCashFlow);
console.log('Bedrooms: '+Bedrooms);
console.log('Bathrooms: '+Bathrooms);
console.log('Status: '+Status);
var infowindow = new google.maps.InfoWindow();
        
	$.ajax({ url: 'getLocations.php',
    data: {
			'location': lct,
			'minYear': minYear,
			'maxYear': maxYear,
			'minPrice': minPrice,
			'maxPrice': maxPrice,
			'minCashFlow': minCashFlow,
			'maxCashFlow': maxCashFlow,
			'Bedrooms': Bedrooms,
			'Bathrooms': Bathrooms,
			'Status':Status
		   },
    type: 'post',
	dataType: 'text',
	success: function(output) 
	{
     	var locations = output;
		var json = $.parseJSON(locations);
		//console.log(json);
		var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 38.874931, lng: -77.276358},
          zoom: 8
        });
		
		var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		var markers = json.map(function(location, i) {
		var marker = new google.maps.Marker({
            			  position: location,
            			  label: labels[i % labels.length]});
			marker.addListener('mouseover', function() {
    					  infowindow.setContent("Latitude:&nbsp;"+location['lat']+",<br/>"+""+"Longitude: &nbsp;"+location['lng']);
						  infowindow.open(marker.get('map'), marker);
  			});
			marker.addListener('mouseout', function() {
						  infowindow.close();
  			});
			
			marker.addListener('click', function() {
						//  window.location.href = "houseListMap.php?ZPID=" + location['ZPID']; 
						// document.getElementById("houseDetails").innerHTML='$ZPID='+location['ZPID'];
						// map.setZoom(16);
    					 //map.setCenter(marker.getPosition());
						 var ZPID = {'ZPID':location['ZPID']};
    					 var saveData = $.ajax({
      										type: "POST",
      										url: "queryDocByZillowID.php",
      										data: ZPID,
      										dataType: "text",
      										success: function(resultData){
          										document.getElementById("houseDetails").innerHTML=resultData;
											}});

  			});
          return marker;
        });//end create marker and listener

        // Add a marker clusterer to manage the markers.
        var markerCluster = new MarkerClusterer(map, markers,{imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});
	  },
	error: function(){
		alert("search fail");
	} 
});//end getLocations.php ajax call
}//end initMap()
	  
    </script>
     <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js">
    </script>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-yR6pOehrdDiQ0Sxxg1BPZ_iTlcLD5S4"
    async defer></script>
  </body>
</html>