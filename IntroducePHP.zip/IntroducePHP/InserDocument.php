<?php
	require 'vendor/autoload.php';
	$client = new MongoDB\Client;
	$zillowdb = $client->mydb;
	$myZillowConll = $zillowdb->myZillow;
	$insertManyResult = $myZillowConll->insertMany([
	    [
		'ZPID'=>'2098099285',
		 'Address'=>'9493-A Silver King Ct # UA2GV9',
		 'Locality'=>'FAIRFAX', 
		 'State'=>'VA',
		 'ZipCode'=>'22031',
		 'Latitude'=>'38.858',
		 'Longitude'=>'-77.270596',
		 'EstimatedPriceRent'=>380900,
		 'Bedrooms'=>2,
		 'Bathrooms'=>2,
		 'AreaSpace'=>1113,
		 'Status'=>'NEW CONSTRUCTION',
		  'EstimatedRent'=>2400,
		  'YearBuilt'=>'2006',
		  'HOAFee'=>568,
		  'DaysonZillow'=>219,
		  'ViewsSinceListing'=>5786,
		  'Index2'=>'6.301',
		  'Mortgage'=>1466,
		  'RentSale'=>'FOR SALE',
		  'AvgIndex2'=>4.297,
		  'CashFlow'=>316.583,
		  'AvgPrice'=>616068,
		  'AvgCashFlow'=>-1032.632,
		  'Avg Rent'=>2254,
		  'PriceperSQFT'=>342,
		  'AvgPriceSQFT'=>298,
		  'StandardDeviation'=>93.9
		 ],
		 [
		 'ZPID'=>'51806787',
		 'Address'=>'9101 Vosger Ct',
		 'Locality'=>'FAIRFAX', 
		 'State'=>'VA',
		 'ZipCode'=>'22031',
		 'Latitude'=>'38.870298',
		 'Longitude'=>'-77.258868',
		 'EstimatedPriceRent'=>489000,
		 'Bedrooms'=>4,
		 'Bathrooms'=>4,
		 'AreaSpace'=>1496,
		 'Status'=>'Make Me Move®',
		 'EstimatedRent'=>2350,
		  'YearBuilt'=>'1972',
		  'HOAFee'=>70,
		  'DaysonZillow'=>0,
		  'ViewsSinceListing'=>43,
		  'Index2'=>'4.806',
		  'Mortgage'=>1937,
		  'RentSale'=>'FOR SALE',
		  'AvgIndex2'=>4.297,
		  'CashFlow'=>-288.25,
		  'AvgPrice'=>616068,
		  'AvgCashFlow'=>-1032.632,
		  'Avg Rent'=>2254,
		  'PriceperSQFT'=>342,
		  'AvgPriceSQFT'=>298,
		  'StandardDeviation'=>93.9
		]
	]);
   printf("Insert %d document",$insertManyResult->getInsertedCount());
   var_dump($insertManyResult ->getInsertedIds());
?>