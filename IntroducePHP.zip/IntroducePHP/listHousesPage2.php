<html>
<head>
	<link href="css/searchHouses.css" rel="stylesheet" type="text/css"/>
	<link href="css/listHousesPage2.css" rel="stylesheet" type="text/css"/>
	<link href="css/header.css" rel="stylesheet" type="text/css">
    <link href="css/listHousesPage1.css" rel = "stylesheet" type="text/css">
    </head>
    <body>
	<div class="header">
            <ul>
  				<li><a href="searchHouses.php">Home</a></li>
  				<li><a href="news.asp">News</a></li>
  				<li><a href="contact.asp">Contact</a></li>
  				<li><a href="about.asp">About</a></li>
			</ul>
     </div>
            <br/>
            <br/>
<table width="1000px" align="center" border="0px solid rgb(128,128,128)">
<tr><td  style="padding:0px; margin:10px; background:rgba(255,255,255,1.0)">

        <?php 
				echo
				'
				<div style="margin:0px; padding:10px;">
				<h2 class="">
				<a href="" style="font-size: 1em;text-decoration: none;">
		        ';    	
				$ZPID = intval($_REQUEST['ZPID']);
				require 'vendor/autoload.php';
				$client = new MongoDB\Client;
				$mydb = $client->mydb;
				$myZillow = $mydb->myZillow;
				$house = $myZillow->findOne([
					'ZPID'=>$ZPID
				]);
				echo 
				'<span id="streetAddress">'
					.$house['Address'].
				'</span>
				,
				<span id="addressLocality">'
				.$house['Locality'].
				'</span>
				<span id="addressState">'
				.$house['State'].
				'</span>
				,
				<span id	="postalCode">'
					.$house['ZipCode'].
				'</span>
		</a>
</h2>

<strong>
	Beds '.$house['Bedrooms'].'* 
	Baths '.$house['Bathrooms'].'*
	Sqft '.$house['AreaSpace'].'
</strong>
</div>
</div>
</td><td  style="padding:0px; margin:10px; background:rgba(255,255,255,1.0)">
		<div>
			<ul style="list-style: none;">
				<li>
					<span style="color:red;">*</span>'.$house['RentSale'].'
				</li>
				<li>
					Zestimate: '.$house['EstimatedPriceRent'].'
				</li>
				<li>
					Est. Mortgage: '.$house['Mortgage'].'/Mo
				</li>
				<li>
					Days on Zillow.com: '.$house['DaysonZillow'].'
				</li>
			</ul>
			<ul style="list-style: none">
				<li>
					Sqft: '.$house['AreaSpace'].'
				</li>
				<li>
					Year Built: '.$house['YearBuilt'].'
				</li>
			</ul>
		</div>'
     ?>
	</td></tr></table>     
<!----<div class="fluidCols description-wrap">
	<div class="l">
		<h2>
			<div class="photoF">
				<div class="mat">
					<img src="http://cdn1.static-homes.com/cgi-bin/readimage/4873647072/100-lillian-chase-ln-herndon-va-20170-0.jpg?resize=1&amp;width=193&amp;height=143&amp;aspect=1" 
					     alt="100 Lillian Chase Ln Herndon VA, 20170"/>
				</div>
			</div>
		</h2>
	</div>

</div>
</div>
</div>
----->
<!--------list  row----------->
