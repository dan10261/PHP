<html>
<head>
<link href="css/searchHouses.css" rel="stylesheet" type="text/css"/>
<link href="css/listHousesPage2.css" rel="stylesheet" type="text/css"/>
<link href="css/header.css" rel="stylesheet" type="text/css">
<link href="https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
<link href="css/listHousesPage1.css" rel = "stylesheet" type="text/css">
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script src="https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script src="js/jquery/sliders.js"></script>
<script src="js/javascript/val_searchyearPrice.js"></script>
<script>
	function val_location(){
		var locationValue = document.getElementById('location').value;
		if(locationValue == "" || locationValue.length == 0){
			alert("This field is required! please enter eg: zip(20170) , state code(VA)  or city name(Fairfax)")
			return false;
		}
		else if( !isNaN(locationValue) &&(locationValue.length != 5)){
			 	alert("zip length should be 5 instead of "+locationValue.length );
				return false;
		}
		return true;
	}
	$(document).ready(function(){
			$("#moreOptionsB").click(function(){
				$("#search-more").css({"display":"block"});
				$("#moreOptionsB").css({"display":"none"});
				$("#lessOptionsB").css({"display":"block"});
			});
			$("#lessOptionsB").click(function(){
				$("#search-more").css({"display":"none"});
				$("#lessOptionsB").css({"display":"none"});
				$("#moreOptionsB").css({"display":"block"});
			});
	});
</script>
</head>
    <body>
		<table width="1000px" align="center">
        <tr>
        <td>
        	<div class="header" >
            <ul>
  				<li><a href="searchHouses.php">Home</a></li>
  				<li><a href="#">News</a></li>
  				<li><a href="#">Contact</a></li>
  				<li><a href="#">About</a></li>
			</ul>
            </div>
        </td>
        </tr>
        <tr><td>
		 <div class="houseImgsPnl" >
			<img alt="house img" src="images/housePage1.jpg"/>
            <div class="houseImgsText"><span>Search for your new house</span></div>
         </div> 
         </td><td>      
		 <div class="searchForSale">	
        	<!--<form id="searchForSale" name="searchForSale" action="listHousesPage1.php" method="post" >-->
            	<form id="searchForSale" name="searchForSale" action="houseListMap.php" method="post"  >			
					
				<div class="searchWrap">
					<div class="searchButton">
						<input type="button" value="Search" onClick="return val_search();">
					</div>
					<div class="details">
						<input type="text" id="location" name="location" placeholder="City(Fairfax), State Code(VA) Or ZIP(20170)">
					</div>
				</div>
				<div class="search-advanced">
                <div class="search-price"   style="clear:both; margin:0px;padding: 10px; width:90%;">
                    	<div style="margin:1px;">
						<label for="slider_price">
							Price Range : <p id="amount"></p>
						</label>
                        <div style="display:block">
						<div id = "slider_price" style="margin:4px 0px"></div>
                        <input type="hidden" id="minPrice" name="minPrice" >
                        <input type="hidden" id="maxPrice" name="maxPrice" >
						</div>
                        </div>
                 </div><!-----end search-price------>
               	
                 
                 <div
                 		style="background-color:transparent; 
                               font-size:15px;
                               border:none; 
                               font-style:oblique;
                               	font-weight:bold;"
                        id = "moreOptionsB">
                        <img width="20px" height="20px" src="images/orange-plus-icon.png"/>
                 </div>
                 <div style="background-color:transparent;
                               font-size:15px; 
                               border:none;
                               display:none;
                               font-style:oblique;
                               font-weight:bold;"
                        id = "lessOptionsB">
						<img width="20px" height="20px" src="images/minus-orange.png"/>
                 </div>
                 <div id="search-more" style="display:none;">	
                 	<div class="search-year"  style="clear:both; margin:0px;padding: 10px; width:90%;"">
                    	<div style="margin:1px;">
						<label for="minYear">
							Year Built : <p id="yearRg"></p>
						</label>
                        </div>
                        <div style="display:block">
                        <div id = "slider_year" style="margin:4px 0px"></div>
						<input type="hidden" id="minYear" name="minYear"/>
						<input type="hidden" id="maxYear" name="maxYear"/>
                        </div>
					</div><!-----end search-year------>

                    <!---
					<div class="search-sqft" style="clear:both; margin:0px;padding: 10px; width:90%;">
                   		 <div style="margin:1px; style="display:block"">
						<label for="silder_SQFT">
							Area Space:<p id="SQFTRg"></p>
						</label>
                        </div>
                        <div style="display:block;">
                         <div id = "slider_SQFT" style="margin:4px 0px"></div>
						<input type="hidden" id="slider_SQFT_min" name="minSQFT"/>
						<input type="hidden" id="slider_SQFT_max" name="maxSQFT"/>
                        </div>
					</div>
                    --->
                   <div class="search-cashFlow" style="clear:both;margin:auto;padding:10px;width:90%; ">
                    	<div style="display:block;">
                        	<label for="CashFlow"> Cash Flow</label>
                        </div>
                        <div style="display:block;">
							From:&nbsp;<input type="text" id="minCashFlow" name="minCashFlow" onChange="return validateMinCashFlow();" style = "border-radius:5px;"/>
							To:&nbsp;<input type="text" id="maxCashFlow" name="maxCashFlow" onChange="return validateMaxCashFlow();" style = "border-radius:5px;"/>
                        </div>
                   </div><!--End: search-cashFlow---->
                    			
                  <div class="search-bb" style="clear:both;margin:auto;padding:0px;width:90%;">
					<label class="search-bb">
						Property Status
						<br>
					<select id="type" name="Status">
							<option value="">
								All Available
							</option>
							<?php include("queryAllHouseStatus.php")?>
                     </select>
					</label>
					
					<label class="search-bb">
						Beds
						<br>
                        <select id="searchBeds" name="Bedrooms">
							<?php include("utils/bld_bedNum.php")?>
						</select>
					</label>
					<label class="search-bb">
						Baths
						<br>
						<select id="searchBaths" name="Bathrooms">
						   	<?php include("utils/bld_bathNum.php")?>
						</select>
					</label>
					</div><!---End search-bb---->
                    
				</div>
			</form>
				</div>
		</div>
        </td></tr></table>
	</body>
	
</html>