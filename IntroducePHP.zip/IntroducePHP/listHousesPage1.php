<html>
<head>
	<link href="css/searchHouses.css" rel="stylesheet" type="text/css"/>
	<link href="css/listHousesPage2.css" rel="stylesheet" type="text/css"/>
	<link href="css/header.css" rel="stylesheet" type="text/css">
    <link href="css/listHousesPage1.css" rel = "stylesheet" type="text/css">
    <style>
	
ul.pagination {
    display: inline-block;
    padding: 0;
    margin: 0;
}

ul.pagination li {display: inline;}

ul.pagination li a {
    color: black;
    float: left;
    padding: 8px 16px;
    text-decoration: none;
}

ul.pagination li a.active {
    background-color: #4CAF50;
    color: white;
}

ul.pagination li a:hover:not(.active) {background-color: #ddd;}
	</style>
    </head>
    <body>
			<div class="header">
            <ul>
  				<li><a href="searchHouses.php">Home</a></li>
  				<li><a href="news.asp">News</a></li>
  				<li><a href="contact.asp">Contact</a></li>
  				<li><a href="about.asp">About</a></li>
			</ul>
            </div>
            <br/>
            <br/>
			<div class="listHousesPg1">
            			<table border="1">
						<thead>
						<th>Address</th>
						<th>City State Zip</th>
					 	<th>EstimatedPrice</th>
			 			<th>Bed/Bath</th>
			 			<th>Status</th>
			 			<th>YearBuilt</th>
			 			<th>Rent/Sale</th>
		  				</thead>
		<?php 
				if(isset($_POST["location"])){
					$location = $_POST["location"];
				}else{
					$location = $_GET["location"];
				}
				include 'queryPartDoc.php';
			foreach($listHouses as $house){
			 echo '<tr>'
			 .'<td><a href = "listHousesPage2.php?ZPID='.$house['ZPID'].'" >'.$house['Address'].'</a></td>'
			 .'<td>'.$house['Locality'].'&nbsp;'.$house['State'].'&nbsp;&nbsp;' .$house['ZipCode'].'</td>'
			 .'<td>'.$house['EstimatedPriceRent'].'</td>'
			 .'<td>'.$house['Bedrooms'].'&nbsp;/'.$house['Bathrooms'].'</td>'
			 .'<td>'.$house['Status'].'</td>'
			 .'<td>'.$house['YearBuilt'].'</td>'
			 .'<td>'.$house['RentSale'].'</td>'
			  .'</tr>';
			 
		}
		    
		echo '
        <tr><td colspan="7">
			 	 <ul class="pagination">';
				   for ($i =0; $i <= ($countAll/10); $i++){
					 echo '<li><a href="listHousesPage1.php?&skip='.$i.'&location='.$location.'">'.($i+1).'</a></li>';
				 }
				echo '</ul></td></tr>';
		?>
         </table>        
			</div>
</body>