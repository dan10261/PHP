<?php
	require 'vendor/autoload.php';
	$client = new MongoDB\Client;
	$zillowdb = $client->mydb;
	$reault1 = $zillowdb->myZillow;
	$cursor = $reault1->find();
	foreach($cursor  as $document){
		echo $document["ZPID"] . $document['Address'] . "\n";
	}	
   
?>