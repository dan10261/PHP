 <?php 
				$ZPID = intval($_POST['ZPID']);
				require 'vendor/autoload.php';
				$client = new MongoDB\Client;
				$mydb = $client->mydb;
				$myZillow = $mydb->myZillow;
				$house = $myZillow->findOne([
					'ZPID'=>$ZPID
				]);
              echo '
<table align="left">
<tr><td  style="padding:10px; margin:0px;">		  		
		<div>
		<h2>
		<span id="streetAddress">'
					.$house['Address'].
				',</span>
				<span id="addressLocality">'
				.$house['Locality'].
				',</span><br/>
				<span id="addressState">'
				.$house['State'].
				',</span>
				<span id	="postalCode">'
					.$house['ZipCode'].
	  '</span>
	  </h2>
	  </div>
		<strong>Beds '.$house['Bedrooms'].'* Baths '.$house['Bathrooms'].'*Sqft '.$house['AreaSpace'].'</strong>
		</td></tr>
		<tr><td  style="padding:0px; margin:0px;">
		<div>
			<ul style="list-style: none;">
				<li>
					<span style="color:red;">*</span>'.$house['RentSale'].'
				</li>
				<li>
					Zestimate: '.$house['EstimatedPriceRent'].'
				</li>
				<li>
					Est. Mortgage: '.$house['Mortgage'].'
				</li>
				<li>
					Days on Zillow.com: '.$house['DaysonZillow'].'
				</li>
			</ul>
			<ul style="list-style: none">
				<li>
					Sqft: '.$house['AreaSpace'].'
				</li>
				<li>
					Year Built: '.$house['YearBuilt'].'
				</li>
				<li>
					Status : '.$house['Status'].'
				</li>
				<li>
					HOAFee: '.$house['HOAFee'].'
				</li>
				<li>
					Days on Zillow: '.$house['DaysonZillow'].'
				</li>
				<li>
					View Since Listing: '.$house['ViewsSinceListing'].'
				</li>
				<li>
					Index2: '.$house['Index2'].'
				</li>
				<li>
					Avg Index2: '.$house['AvgIndex2'].'
				</li>
				<li>
					Cash Flow: '.$house['CashFlow'].'
				</li>
				<li>
					Avg Price: '.$house['AvgPrice'].'
				</li>
				<li>
					Avg Cash Flow: '.$house['AvgCashFlow'].'
				</li>
				
				<li>
					Avg Rent: '.$house['AvgRent'].'
				</li>
				<li>
					Price per SQFT: '.$house['PriceperSQFT'].'
				</li>
				<li>
					Avg Price SQFT: '.$house['AvgPriceSQFT'].'
				</li>
				<li>
					Standard Deviation: '.$house['StandardDeviation'].'
				</li>
			</ul>
		</div>
</td></tr></table> 
			  
		  ';
?>